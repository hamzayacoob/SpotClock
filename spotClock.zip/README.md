# SpotClock
An alarm clock that makes use of Spotify's API to enable Spotify music to be used as an alarm tone.
